This is a Photobooth project implemented in js based on the mvc model



Requirements :


	- Nodejs : you can install it from the command line by typing this command on the terminal :

	$ sudo apt-get install nodejs


	Or you can get it through the GUI by clicking on the link below :

	https://nodejs.org/en/download/


	- npm : by installing nodejs in graphical mode, this includes npm


	Or you can install it from the command line by typing this command on the terminal :

	$ sudo apt-get install npm



Demonstration :


	Open a new terminal from hello-node folder and type :


	$ sudo node index


	Then go to the web browser and type localhost in the address bar so you can see the photobooth interface
